#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/7/1 9:22 下午"
@Author:lydia_liu"
@File:test_department_single.py
@function:单接口部门
"""
import pytest
import requests


class TestDepartmentSingle:
        def setup_class(self):
            corpid = "ww5d9a0a4541c8436a"
            secret = 'PqPbJoZU2En5__7he3LGxX3Q17ZOFZdoDUoBdx8Z-4Y'
            url = f'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={corpid}&corpsecret={secret}'
            r = requests.request(method="GET", url=url)
            self.token = r.json()["access_token"]
        @pytest.mark.parametrize(
            "name, name_en,parentid,order,depart_id,expect",
            [
              ("技术部","jishu1",1,5,6,60011),
              ("技术部#$%^&", "jishu2", 1, 6, 1,60011),
              ("技术部34tdfgrt45ersdfsfsdfeff4", "jishu3", 1, 7, 8,60011),
            ]
        )
        def test_create_department(self,name, name_en,parentid,order,depart_id,expect):
            url = f'https://qyapi.weixin.qq.com/cgi-bin/department/create?access_token={self.token}'
            data = {
                "name": name,
                "name_en": name_en,
                "parentid": parentid,
                "order": order,
                "id": depart_id
            }
            r = requests.request(method="POST",url=url,json=data)
            print(r.json())
            assert r.json()["errcode"] == expect



