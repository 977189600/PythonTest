#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/7/10 4:23 下午"
@Author:lydia_liu"
@File:wework.py
@function:
"""
# import requests

from test_request.apis.base_api import BaseApi


class WeWork(BaseApi):
    def __init__(self,corpid,secret):
        self.token = self.get_access_token(corpid,secret)

    def get_access_token(self,corpid,secret):
        """
        获取 access_token
        :return:
        """

        # corpid = "ww5d9a0a4541c8436a"
        # secret = 'PqPbJoZU2En5__7he3LGxX3Q17ZOFZdoDUoBdx8Z-4Y'
        #url = f'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={corpid}&corpsecret={secret}'
        req = {
            "method":"GET",
            "url":"https://qyapi.weixin.qq.com/cgi-bin/gettoken",
            "params":{
                "corpid":corpid,
                "corpsecret":secret
            }

        }
        r = self.send_api(req)
        #r = requests.request(method="GET", url=url)
        token = r.json()["access_token"]
        return token



