#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/7/11 2:26 下午"
@Author:lydia_liu"
@File:department.py
@function:
"""
#import requests

from test_request.apis.wework import WeWork
from test_request.testcase.utils import Utils

"""
接口信息描述，只关注业务，不需要做断言
"""
class Department(WeWork):
    def create_department(self,data):
        """
        创建部门
        :return: 创建部门接口的响应
        """
        create_url = f'https://qyapi.weixin.qq.com/cgi-bin/department/create?access_token={self.token}'
        #1、把接口信息请求信息封装到字典中
        #2、接口中不需要再引入requests
        req = {
            "method":"POST",
            "url":create_url,
            "json":data

        }
        #r = requests.request(method="POST", url=create_url, json=data)
        r = self.send_api(req)
        return r.json()

    def update_department(self,data):
        """
        更新部门信息
        :return: 更新部门接口的响应
        """
        update_url = f"https://qyapi.weixin.qq.com/cgi-bin/department/update?access_token={self.token}"
        req = {
            "method":"POST",
            "url":update_url,
            "json":data
        }
        r = self.send_api(req)
        #r = requests.request(method='POST', url=url, json=data)
        return r.json()



    def delect_department(self,depart_id):
        """
        删除部门
        :return: 删除部门接口的响应
        """
        delect_url = f"https://qyapi.weixin.qq.com/cgi-bin/department/delete?access_token={self.token}&id={depart_id}"
        req = {
            "method":"GET",
            "url":delect_url
        }
        #r = requests.request(method="GET", url=url)
        r = self.send_api(req)
        return r.json()

    def select_department(self):
        """
        查询部门列表
        :return: 查询部门接口的响应
        """
        select_url = f"https://qyapi.weixin.qq.com/cgi-bin/department/list?access_token={self.token}"
        req = {
            "method":"GET",
            "url":select_url
        }
        r = self.send_api(req)
        #r = requests.request(method="GET", url=url)
        return r.json()

    def clear_department(self):
        """
        清理已存在的部门信息
        :return:
        """
        #查看目前已存在的部门
        department_info = self.select_department()
        #获取部门id列表
        id_list = Utils.base_jsonpath(department_info,'$..id')
        #id为1的是最基础的副部门，是不能删除的。
        for i in id_list:
            if i != 1:
              #调用删除接口部门
              self.delect_department(i)