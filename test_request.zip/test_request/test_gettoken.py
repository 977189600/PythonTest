#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/6/27 6:26 下午"
@Author:lydia_liu"
@File:test_gettoken.py
@function:
"""
import requests


class TestToken:
    #第一种方式：
    def test_get_token(self):

        """
        https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=ID&corpsecret=SECRET
        获取access_token
        :return:
        """
        #corpid = 'wwd88ffb3cf55b0fc1'
        corpid = "ww5d9a0a4541c8436a"
        secret = 'PqPbJoZU2En5__7he3LGxX3Q17ZOFZdoDUoBdx8Z-4Y'
        url = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken'
        params = {
            "corpid":corpid,
            "corpsecret":secret
        }
        #发出get请求
        r = requests.get(url,params=params)
        print(r.json())
    def get_accesstoken(self):
    #第二种方式：
        corpid = "ww5d9a0a4541c8436a"
        secret = 'PqPbJoZU2En5__7he3LGxX3Q17ZOFZdoDUoBdx8Z-4Y'
        url = f'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={corpid}&corpsecret={secret}'
        r = requests.request("GET",url)
        print(r.json())
