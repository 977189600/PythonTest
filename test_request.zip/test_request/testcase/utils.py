#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/7/14 10:06 下午"
@Author:lydia_liu"
@File:utils.py
@function:
"""
import yaml
from jsonpath import jsonpath


class Utils:

    @classmethod
    def get_yaml_data(cls,file_path):
        """
        封装YAML文件读取的方法
        :param file_path:yaml文件的路径
        :return:字典格式的yaml文件内容
        """
        with open (file_path) as f:
            datas = yaml.safe_load(f)
        return datas

    @classmethod
    def base_jsonpath(cls,obj,json_expr):
        """
        封装jsonpath断言
        obj:要断言的响应内容
        json_expr:jsonpath表达式
        :return:获取内容的列表
        """
        return jsonpath(obj,json_expr)
