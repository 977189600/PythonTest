#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/7/11 2:45 下午"
@Author:lydia_liu"
@File:test_department.py
@function:
"""
import allure

from test_request.apis.department import Department
from test_request.testcase.utils import Utils

@allure.feature("部门管理测试")
class TestDepartment:


    def setup_class(self):
        #获取通讯录管理的token参数
        conf_data = Utils.get_yaml_data("../data/conf.yaml")
        corpid = conf_data["corpid"]["hogwarts"]
        corpsecret = conf_data["secret"]["contact_secret"]

        #实例化部门类
        self.department = Department(corpid,corpsecret)

        #清除部门数据
        self.department.clear_department()

        #准备测试数据
        self.depart_id = 4
        self.create_date={
            "name": "广州研发中心2",
            "name_en": "RDGZ",
            "parentid": 1,
            "order": 2,
            "id": self.depart_id
            }
        self.update_date={
            "id": self.depart_id,
            "name": "广州研发中心-update",
            "name_en": "RDGZ",
            "parentid": 1,
            "order": 1
        }

    @allure.story("部门操作场景用例")
    def test_department_scene(self):
        """
        部门增删改查场景测试
        :return:
        """
        #创建部门
        with allure.step("创建部门"):
            self.department.create_department(self.create_date)
        #查询部门:查询是否创建成功
        with allure.step("查询部门创建的结果"):
            depart_info = self.department.select_department()
            # assert depart_info["department"][1]["name"] == '广州研发中心2'
            #通过jsonpath进行断言
            name_list = Utils.base_jsonpath(depart_info,"$..name")
            assert "广州研发中心2" in name_list

        #更新部门
        with allure.step("更新部门"):
            self.department.update_department(self.update_date)
        #查询是否更新成功
        with allure.step("查询部门更新的结果"):
            depart_info = self.department.select_department()
            # assert  depart_info["department"][1]["name"]=='广州研发中心-update'
            #通过jsonpath进行断言
            name_list = Utils.base_jsonpath(depart_info,"$..name")
            assert "广州研发中心-update" in name_list

        #删除部门
        with allure.step("删除部门"):
            self.department.delect_department(self.depart_id)
        #查询是否删除成功
        with allure.step("查询删除的结果"):
            depart_info = self.department.select_department()
            print(depart_info)
            # assert len(depart_info["department"])=='1'
            # 通过jsonpath把所有部门的ID提取出来
            id_list = Utils.base_jsonpath(depart_info, "$..id")
            self.department.log_info(id_list)
            assert self.depart_id not in id_list

