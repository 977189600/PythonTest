#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/6/29 9:53 下午"
@Author:lydia_liu"
@File:test_wework.py
@function:创建企业微信部门，
"""
import requests


class TestWework:
    def setup_class(self):
        corpid = "ww5d9a0a4541c8436a"
        secret = 'PqPbJoZU2En5__7he3LGxX3Q17ZOFZdoDUoBdx8Z-4Y'
        url = f'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={corpid}&corpsecret={secret}'
        r = requests.request(method="GET",url= url)
        self.token = r.json()["access_token"]
        self.depart_id = 3

    def test_create_department(self):
        """
        创建部门
        请求方式：POST（HTTPS）
        请求地址：https://qyapi.weixin.qq.com/cgi-bin/department/create?access_token=ACCESS_TOKEN
        """
        url = 'https://qyapi.weixin.qq.com/cgi-bin/department/create'
        data = {
            "name": "广州研发中心2",
            "name_en": "RDGZ",
            "parentid": 1,
            "order": 2,
            "id": self.depart_id
            }
        params = {
        "access_token":self.token
        }
        r = requests.request(method="POST",url=url,params=params,json=data)
        print(r.json())
        assert r.json()["errcode"] == 0
        #通过查询部门列表接口拿到部门信息
        depart_info = self.test_select_department()
        assert depart_info["department"][2]["name"]=='广州研发中心2'

    def test_updata_department(self):
        """
        更新部门信息
        请求方式：POST（HTTPS）
        请求地址：https://qyapi.weixin.qq.com/cgi-bin/department/update?access_token=ACCESS_TOKEN
        """
        url = f"https://qyapi.weixin.qq.com/cgi-bin/department/update?access_token={self.token}"
        data = {
            "id": self.depart_id,
            "name": "广州研发中心3",
            "name_en": "RDGZ",
            "parentid": 1,
            "order": 1
        }
        r = requests.request(method='POST',url=url,json = data)
        print(r.json())
        assert r.json()["errcode"] == 0
        #通过查询部门接口获取到部门信息
        depart_info = self.test_select_department()
        assert  depart_info["department"][1]["name"]=='广州研发中心3'


    def test_delete_department(self):
        #删除部门
        """
        请求方式：GET（HTTPS）
        请求地址：https://qyapi.weixin.qq.com/cgi-bin/department/delete?access_token=ACCESS_TOKEN&id=ID
        """

        url = f"https://qyapi.weixin.qq.com/cgi-bin/department/delete?access_token={self.token}&id={self.depart_id}"
        r = requests.request(method="GET",url=url)
        print(r.json())
        assert r.json()["errcode"] == 0
        #通过查询部门接口获取到部门信息
        depart_info = self.test_select_department()
        assert len(depart_info["department"])==1


    def test_select_department(self):
        #查询全量部门信息
        """
        请求方式：GET（HTTPS）
        请求地址：https://qyapi.weixin.qq.com/cgi-bin/department/list?access_token=ACCESS_TOKEN&id=ID
        :return:
        """

        url = f"https://qyapi.weixin.qq.com/cgi-bin/department/list?access_token={self.token}"
        r = requests.request(method="GET",url=url)
        print(r.json())
        assert r.json()["errcode"]==0
        return r.json()
