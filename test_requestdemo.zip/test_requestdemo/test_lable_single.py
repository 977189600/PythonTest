#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/8/11 5:13 下午"
@Author:lydia_liu"
@File:test_lable_single.py
@function:单接口自动校验用例
"""
import pytest
import requests

class TestLableSingle():

    def setup_class(self):
        # 定义凭证
        corp_id = 'wwd88ffb3cf55b0fc1'
        corp_secret = 'SjA8LhfEuDtXVFb-k1eRLKItszKeCxPhPJDYbEI3NVM'
        url = f'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={corp_id}&corpsecret={corp_secret}'
        # 发出get请求
        r = requests.request(method='GET', url=url)
        self.token = r.json()["access_token"]

    @pytest.mark.parametrize(
        "tagname,tagid,expert",
        [
            ('UI3',13,0),
            ('UI412345678901234567ytrewqasdfgh3',14,40058),
            ('UI4@#$', 15,0),
            ('UI2', 13,40068),
            ('UI5',-1,-1)
        ]

    )

    def test_creat_label(self,tagname,tagid,expert):
        """
        创建标签
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/create?access_token={self.token}'
        data = {
            "tagname": tagname,
            "tagid": tagid
        }
        r = requests.request(method='POST', json=data, url=url)
        print(r.json())
        assert r.json()["errcode"] == expert

    @pytest.mark.parametrize(
        "tagid,tagname,expert",
        [
            (15,'biaoqian15',0),
            (13,'biaoqian13biaoqian13biaoqian13131',40058)
        ]
    )
    def test_update_label(self,tagid,tagname,expert):
        """
        更新标签
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/update?access_token={self.token}'
        data = {
            "tagid": tagid,
            "tagname": tagname
        }
        r = requests.request(method='POST',json=data,url=url)
        print(r.json())
        assert r.json()["errcode"] == expert

    @pytest.mark.parametrize(
        "tagid,expert",
        [
            (13,0),
            (14,40068)
        ]
    )
    def test_delete_lable(self,tagid,expert):
        """
        删除标签
        :return:
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/delete?access_token={self.token}&tagid={tagid}'
        r = requests.request(method='GET',url=url)
        print(r.json())
        assert r.json()["errcode"] == expert

    @pytest.mark.parametrize(
        "tagid,expert",
        [
            (15, 0),
            (14, 40068)
        ]
    )
    def test_select_lable(self,tagid,expert):
        """
        获取标签成员
        :return:
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/get?access_token={self.token}&tagid={tagid}'
        r = requests.request(method='GET',url=url)
        print(r.json())
        assert r.json()["errcode"] == expert

    @pytest.mark.parametrize(
        "tagid,userlist,partylist,expert",
        [
            (15,"hh",1,0),
           (15,"hogwarts1",2,0), #异常场景：不存在的成员
           (14,"hh",1,40068) #异常场景：不存在的标签id
        ]
    )
    def test_add_lable(self,tagid,userlist,partylist,expert):
        """
        1、增加标签成员
        请求方式：POST（HTTPS）
        请求地址：https://qyapi.weixin.qq.com/cgi-bin/tag/addtagusers?access_token=ACCESS_TOKEN
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/addtagusers?access_token={self.token}'
        data = {
            "tagid": tagid,
            "userlist":[userlist],
            "partylist": [partylist]
        }
        r = requests.request(method='POST',url=url,json=data)
        print(r.json())
        assert r.json()["errcode"] == expert

    @pytest.mark.parametrize(
        "tagid,userlist,partylist,expert",
        [
            (15, "hh", 1, 0)
        ]
    )
    def test_delete_lable(self,tagid,userlist,partylist,expert):
        """
        删除标签成员
        请求方式：POST（HTTPS）
        请求地址：https://qyapi.weixin.qq.com/cgi-bin/tag/deltagusers?access_token=ACCESS_TOKEN
        :return:
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/deltagusers?access_token={self.token}'
        data = {
            "tagid": tagid,
            "userlist":[userlist],
            "partylist": [partylist]
        }
        r = requests.request(method='POST',url=url,json=data)
        print(r.json())
        assert r.json()["errcode"] == expert

    @pytest.mark.parametrize(
        "tagid,expert",
        [
            (15, 0)
        ]
    )
    def test_get_lable(self,tagid,expert):
        """
        获取标签列表
        请求方式：GET（HTTPS）
        请求地址：https://qyapi.weixin.qq.com/cgi-bin/tag/list?access_token=ACCESS_TOKEN
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/list?access_token={self.token}'
        r = requests.request(method='GET',url=url)
        print(r.json())
        assert r.json()["errcode"] == expert





