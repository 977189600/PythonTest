#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/8/9 9:18 下午"
@Author:lydia_liu"
@File:test_token.py
@function:获取token
请求方式： GET（HTTPS）
请求地址： https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=ID&corpsecret=SECRET

企业ID：wwd88ffb3cf55b0fc1
Secret：SjA8LhfEuDtXVFb-k1eRLKItszKeCxPhPJDYbEI3NVM
"""
import requests


class TestToken:
    def test_get_token(self):
        """
        获取 access_token
        :return:
        """
        corp_id='wwd88ffb3cf55b0fc1'
        corp_secret='SjA8LhfEuDtXVFb-k1eRLKItszKeCxPhPJDYbEI3NVM'
        url = f'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={corp_id}&corpsecret={corp_secret}'

        #发出get请求
        r = requests.request(method='GET',url=url)
        #查看响应信息
        print(r.json())
        assert r.json()["errcode"]==0
        return r.json()
