#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/8/16 11:04 下午"
@Author:lydia_liu"
@File:test_lable.py
@function:
"""
import allure
import self as self
from jsonpath import jsonpath

from test_requestdemo.apis.lable import Label
from test_requestdemo.testcase.utils import Utils

@allure.feature("标签管理测试")
class TestLabel:
    def setup_class(self):
        #获取通讯录管理的token参数
        token_data = Utils.get_yamlfile_data("../data/conf.yaml")
        corp_id = token_data["corpid"]["qiyeweixing"]
        corp_secret = token_data["corpsecret"]["contact_secret"]
        #实例化标签类
        self.label = Label(corp_id,corp_secret)
        #清空已存在的标签信息
        self.label.clear_labels()

        #准备测试数据
        self.tagid = 12
        self.create_data = {
            "tagid": self.tagid,
            "tagname": "UI2"

        }
        self.update_data = {
            "tagid": self.tagid,
            "tagname": "UI design1"
        }

        self.createmember_data={
            "tagid": self.tagid,
            "userlist": ["LiuYu"],
            "partylist": [1]
        }
        self.deletemember_data = {
            "tagid": self.tagid,
            "userlist": ["LiuYu"],
            "partylist": [1]
        }

    @allure.story("标签管理场景用例")
    def test_label_scene(self):
        """标签增删改查的场景用例"""
        #创建标签
        with allure.step("创建标签"):
            self.label.create_label(self.create_data)

        with allure.step("查询标签是否创建成功"):
            #查询是否创建成功
            label_info = self.label.get_label()
            print(label_info)
            # assert label_info['taglist'][0]['tagname'] == "UI2"
            #通过jsonpath去断言
            tagname_list = Utils.base_jsonpath(label_info,"$..tagname")
            self.label.log_info(tagname_list)
            assert "UI2" in tagname_list

        #更新标签
        with allure.step("更新标签"):
            self.label.update_label(self.update_data)

        with allure.step("查询标签是否更新成功"):
        #查询是否更新成功
            label_info = self.label.get_label()
            print(label_info)
            #assert label_info["taglist"][0]['tagname'] == "UI design1"
            #通过jsonpath去断言
            tagname_list = Utils.base_jsonpath(label_info, "$..tagname")
            self.label.log_info(tagname_list)
            assert "UI design1" in tagname_list

        # 增加标签成员
        with allure.step("增加标签成员"):
            self.label.add_member_label(self.createmember_data)

        with allure.step("查看标签的成员是否添加成功"):
            labelmember_info = self.label.get_member_label(self.tagid)
            print(labelmember_info)
            #assert labelmember_info["userlist"][0]["userid"] == "LiuYu"
            # 通过jsonpath去断言
            tagname_list = Utils.base_jsonpath(labelmember_info, "$..userid")
            self.label.log_info(tagname_list)
            assert "LiuYu" in tagname_list

        # 删除标签成员
        with allure.step("删除标签成员"):
            self.label.delete_member_label(self.deletemember_data)

        with allure.step("查看标签的成员删除结果"):
            labelmember_info = self.label.get_member_label(self.tagid)
            print(labelmember_info)
            #assert len(labelmember_info["userlist"]) == 0
            #获取所有的标签成员
            user_list = Utils.base_jsonpath(labelmember_info,"$..userlist")
            self.label.log_info(user_list)
            assert "LiuYu" not in user_list


        #删除标签
        with allure.step("删除标签"):
            self.label.delete_label(self.tagid)

        with allure.step("查看删除标签的结果"):
            lable_info = self.label.get_label()
            print("8888",lable_info)
            #assert len(lable_info['taglist']) == 1
            # 获取所有的标签id
            tagid_list = Utils.base_jsonpath(lable_info, "$..tagid")
            self.label.log_info(tagid_list)
            if tagid_list:
                assert self.tagid not in tagid_list




