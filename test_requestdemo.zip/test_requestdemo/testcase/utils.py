#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/8/18 4:04 下午"
@Author:lydia_liu"
@File:utils.py
@function: 工具类
"""
import yaml
from jsonpath import jsonpath


class Utils:

    @classmethod
    def get_yamlfile_data(cls,file_path):
        """
        封裝yaml文件的读取
        :param file_path:yaml文件的路径
        :return:字典格式的yaml文件的内容
        """
        with open(file_path) as f:
            data = yaml.safe_load(f)
        return data
    @classmethod
    def base_jsonpath(cls,obj,json_expr):
        """
        封装jsonpath 断言
        :param obj: 要断言的jsonpath的响应内容
        :param json_expr: jsonpath表达式
        :return:提取内容的列表
        """
        return jsonpath(obj,json_expr)
