#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/8/6 4:54 下午"
@Author:lydia_liu"
@File:wework.py
@function:
"""
import requests

from test_requestdemo.apis.base_api import BaseApi

"""

企业ID：wwd88ffb3cf55b0fc1
Secret：SjA8LhfEuDtXVFb-k1eRLKItszKeCxPhPJDYbEI3NVM

1、创建标签
调试工具
请求方式：POST（HTTPS）
请求地址：https://qyapi.weixin.qq.com/cgi-bin/tag/create?access_token=ACCESS_TOKEN

请求包体：

{
   "tagname": "UI",
   "tagid": 12
}

2、更新标签名字
请求方式：POST（HTTPS）
请求地址：https://qyapi.weixin.qq.com/cgi-bin/tag/update?access_token=ACCESS_TOKEN
请求包体：
{
   "tagid": 12,
   "tagname": "UI design"
}

3、删除标签
请求方式：GET（HTTPS）
请求地址：https://qyapi.weixin.qq.com/cgi-bin/tag/delete?access_token=ACCESS_TOKEN&tagid=TAGID

4、获取标签成员
请求方式：GET（HTTPS）
请求地址：https://qyapi.weixin.qq.com/cgi-bin/tag/get?access_token=ACCESS_TOKEN&tagid=TAGID

通讯录管理-标签管理接口，至少实现前4个
设计用例，分为【单接口自动校验用例】和【业务流程相关用例】
 使用pytest+requests 实现用例
 使用api object 设计模式进行改造
 使用jsonpath优化断言内容，加入wework层级处理token,把jsonpath封装到最底层
"""

class TestWework(BaseApi):
    def setup_class(self):
        #定义凭证
        corp_id = 'wwd88ffb3cf55b0fc1'
        corp_secret = 'SjA8LhfEuDtXVFb-k1eRLKItszKeCxPhPJDYbEI3NVM'
       # url = f'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={corp_id}&corpsecret={corp_secret}'
        req = {
            "url":"https://qyapi.weixin.qq.com/cgi-bin/gettoken",
            "method":"GET",
            "params":{
                "corpid":corp_id,
                "corpsecret":corp_secret
            }
        }
        #发出get请求
        #r = requests.request(method='GET',url=url)
        r = BaseApi.send_api(req)
        self.token = r.json()["access_token"]
        self.tagid = 12

    def test_creat_label(self):
        """
        创建标签
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/create?access_token={self.token}'
        data = {
            "tagname": "UI2",
            "tagid": self.tagid
        }

        r = requests.request(method='POST',json=data,url=url)
        print(r.json())

        #查询获取标签的列表信息
        lable_info = self.test_get_lable()
        assert lable_info['taglist'][0]['tagname'] == "UI2"

    def test_update_label(self):
        """
        更新标签
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/update?access_token={self.token}'
        data = {
            "tagid": self.tagid,
            "tagname": "UI design1"
        }
        r = requests.request(method='POST',url=url,json=data)
        print(r.json())
        #查询获取标签列表的信息
        lable_info = self.test_get_lable()
        assert lable_info["taglist"][0]['tagname'] == 'UI design1'
        #assert r.json()["errmsg"] == 'updated'

    def test_delete_lable(self):
        """
        删除标签
        :return:
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/delete?access_token={self.token}&tagid={self.tagid}'
        r = requests.request(method='GET',url=url)
        print(r.json())
        #assert r.json()["errmsg"] == 'deleted'
        #获取标签列表接口信息
        lable_info = self.test_get_lable()
        assert len(lable_info['taglist']) == 1


    def test_select_lable(self):
        """
        获取标签成员
        :return:
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/get?access_token={self.token}&tagid={self.tagid}'
        r = requests.request(method='GET',url=url)
        print(r.json())
        #获取标签列表接口信息
        lable_info = self.test_get_lable()
        assert lable_info["taglist"][0]["tagid"] == 12
        return r.json()


    def test_add_lable(self):
        """
        1、增加标签成员
        请求方式：POST（HTTPS）
        请求地址：https://qyapi.weixin.qq.com/cgi-bin/tag/addtagusers?access_token=ACCESS_TOKEN
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/addtagusers?access_token={self.token}'
        data = {
            "tagid": self.tagid,
            "userlist":[ "LiuYu"],
            "partylist": [1]
        }
        r = requests.request(method='POST',url=url,json=data)
        print(r.json())
        #assert r.json()["errmsg"] == 'ok'
        lable_info = self.test_select_lable()
        assert lable_info["userlist"][0]["userid"] == "LiuYu"


    def test_delete_lable(self):
        """
        删除标签成员
        请求方式：POST（HTTPS）
        请求地址：https://qyapi.weixin.qq.com/cgi-bin/tag/deltagusers?access_token=ACCESS_TOKEN
        :return:
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/deltagusers?access_token={self.token}'
        data = {
            "tagid": self.tagid,
            "userlist":["LiuYu"],
            "partylist": [1]
        }
        r = requests.request(method='POST',json=data,url=url)
        print(r.json())
        #assert r.json()["errmsg"] == 'deleted'
        lable_info = self.test_select_lable()
        assert len(lable_info["userlist"]) == 0

    def test_get_lable(self):
        """
        获取标签列表
        请求方式：GET（HTTPS）
        请求地址：https://qyapi.weixin.qq.com/cgi-bin/tag/list?access_token=ACCESS_TOKEN
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/list?access_token={self.token}'
        r = requests.request(method='GET' ,url=url)
        print(r.json())
        assert r.json()["errcode"] == 0
        return r.json()



