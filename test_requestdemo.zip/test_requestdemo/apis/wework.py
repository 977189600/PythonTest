#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/8/6 4:54 下午"
@Author:lydia_liu"
@File:wework.py
@function:
"""
#import requests

from test_requestdemo.apis.base_api import BaseApi

"""

企业ID：wwd88ffb3cf55b0fc1
Secret：SjA8LhfEuDtXVFb-k1eRLKItszKeCxPhPJDYbEI3NVM

企业微信特有逻辑，完成 access_token 获取
"""
class WeWork(BaseApi):
    def __init__(self,corp_id,corp_secret):

        self.token = self.get_access_token(corp_id,corp_secret)


    def get_access_token(self,corp_id,corp_secret):
        """
        获取access_token
        :return:access_token值，方便其他接口进行调用
        """

        # corp_id = 'wwd88ffb3cf55b0fc1'
        # corp_secret = 'SjA8LhfEuDtXVFb-k1eRLKItszKeCxPhPJDYbEI3NVM'
        #url = f'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={corp_id}&corpsecret={corp_secret}'
        # 发出get请求
        req = {
            "url": "https://qyapi.weixin.qq.com/cgi-bin/gettoken",
            "method": "GET",
            "params": {
                "corpid": corp_id,
                "corpsecret": corp_secret
            }
        }
        # 发出get请求
        # r = requests.request(method='GET',url=url)
        r = self.send_api(req)
        print(r.json())
        token = r.json()["access_token"]
        #self.token = r.json()["access_token"]
        return token



