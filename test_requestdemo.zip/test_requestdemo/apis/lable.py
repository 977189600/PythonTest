#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
@Time:2021/8/16 10:18 下午"
@Author:lydia_liu"
@File:lable.py
@function:
"""
#import requests


from test_requestdemo.apis.wework import WeWork
from test_requestdemo.testcase.utils import Utils

"""
接口信息描述：只关注业务，不做断言
"""
class Label(WeWork):

    def create_label(self,data):
        """
        创建标签
        :return:创建标签接口的响应
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/create?access_token={self.token}'
        """
        1、把接口的信息封装到字典信息中
        2、接口中不在需要引入requests
        """
        req = {
            "method":"POST",
            "url":url,
            "json":data
            }
        #r = requests.request(method='POST',json=data,url=url)
        r = self.send_api(req)
        return r.json()


    def update_label(self,data):
        """
        更新标签
        :return:更新标签接口的响应
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/update?access_token={self.token}'
        req = {
            "method":"POST",
            "json":data,
            "url":url
        }
        #r = requests.request(method='POST',json=data,url=url)
        r = self.send_api(req)
        return r.json()

    def delete_label(self,tagid):
        """
        删除标签
        :return:删除标签接口的响应
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/delete?access_token={self.token}&tagid={tagid}'
        req = {
            "method":"GET",
            "url":url
        }
        #r = requests.request(method='GET', url=url)
        r = self.send_api(req)
        return r.json()

    def get_member_label(self,tagid):
        """
        获取标签成员信息
        :return:获取标签成员接口的响应
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/get?access_token={self.token}&tagid={tagid}'
        req = {
            "method": "GET",
            "url": url
        }
        # r = requests.request(method='GET', url=url)
        r = self.send_api(req)
        return r.json()

    def add_member_label(self,data):
        """
        添加标签成员
        :return:添加标签成员接口的响应
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/addtagusers?access_token={self.token}'
        req = {
            "method": "POST",
            "url": url,
            "json":data
        }
        #r = requests.request(method='POST', url=url, json=data)
        r = self.send_api(req)
        return r.json()

    def delete_member_label(self,data):
        """
        删除标签成员信息
        :return:删除标签成员接口的响应
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/deltagusers?access_token={self.token}'
        req = {
            "method": "POST",
            "url": url,
            "json": data
        }
        #r = requests.request(method='POST', json=data, url=url)
        r = self.send_api(req)
        return r.json()

    def get_label(self):

        """
        获取标签列表
        :return:获取标签列表接口的响应
        """
        url = f'https://qyapi.weixin.qq.com/cgi-bin/tag/list?access_token={self.token}'
        req = {
            "method": "GET",
            "url": url
        }
        #r = requests.request(method='GET', url=url)
        r = self.send_api(req)
        return r.json()

    def clear_labels(self):
        """
        清空已存在的标签信息
        :return:
        """
        #查询所有的标签信息
        label_info = self.get_label()
        #获取标签id列表
        tagid_list = Utils.base_jsonpath(label_info,"$..tagid")
        print("_______",tagid_list)
        if tagid_list:
            for i in tagid_list[0]:
                    #调用删除标签的接口
                    self.delete_label(i)


